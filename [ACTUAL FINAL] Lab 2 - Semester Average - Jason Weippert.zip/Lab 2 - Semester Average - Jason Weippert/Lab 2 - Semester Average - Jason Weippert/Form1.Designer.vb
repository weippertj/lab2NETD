﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSemesterGrades
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblCourse1 = New System.Windows.Forms.Label()
        Me.txtCourse1 = New System.Windows.Forms.TextBox()
        Me.lblCourse2 = New System.Windows.Forms.Label()
        Me.lblCourse3 = New System.Windows.Forms.Label()
        Me.lblCourse4 = New System.Windows.Forms.Label()
        Me.lblCourse5 = New System.Windows.Forms.Label()
        Me.lblCourse6 = New System.Windows.Forms.Label()
        Me.txtCourse2 = New System.Windows.Forms.TextBox()
        Me.txtCourse5 = New System.Windows.Forms.TextBox()
        Me.txtCourse4 = New System.Windows.Forms.TextBox()
        Me.txtCourse3 = New System.Windows.Forms.TextBox()
        Me.txtCourse6 = New System.Windows.Forms.TextBox()
        Me.lblCourse1Grade = New System.Windows.Forms.Label()
        Me.lblCourse2Grade = New System.Windows.Forms.Label()
        Me.lblCourse3Grade = New System.Windows.Forms.Label()
        Me.lblCourse4Grade = New System.Windows.Forms.Label()
        Me.lblCourse5Grade = New System.Windows.Forms.Label()
        Me.lblCourse6Grade = New System.Windows.Forms.Label()
        Me.lblSemester = New System.Windows.Forms.Label()
        Me.lblSemesterPercent = New System.Windows.Forms.Label()
        Me.lblSemesterGrade = New System.Windows.Forms.Label()
        Me.lblOutput = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.ttipSemesterAverage = New System.Windows.Forms.ToolTip(Me.components)
        Me.SuspendLayout()
        '
        'lblCourse1
        '
        Me.lblCourse1.Location = New System.Drawing.Point(12, 15)
        Me.lblCourse1.Name = "lblCourse1"
        Me.lblCourse1.Size = New System.Drawing.Size(49, 13)
        Me.lblCourse1.TabIndex = 0
        Me.lblCourse1.Text = "&Course 1"
        Me.lblCourse1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtCourse1
        '
        Me.txtCourse1.Location = New System.Drawing.Point(76, 12)
        Me.txtCourse1.Name = "txtCourse1"
        Me.txtCourse1.Size = New System.Drawing.Size(100, 20)
        Me.txtCourse1.TabIndex = 1
        Me.txtCourse1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ttipSemesterAverage.SetToolTip(Me.txtCourse1, "The textbox that the user enters the Course 1 grade.")
        '
        'lblCourse2
        '
        Me.lblCourse2.Location = New System.Drawing.Point(12, 55)
        Me.lblCourse2.Name = "lblCourse2"
        Me.lblCourse2.Size = New System.Drawing.Size(49, 13)
        Me.lblCourse2.TabIndex = 3
        Me.lblCourse2.Text = "&Course 2"
        Me.lblCourse2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblCourse3
        '
        Me.lblCourse3.Location = New System.Drawing.Point(12, 92)
        Me.lblCourse3.Name = "lblCourse3"
        Me.lblCourse3.Size = New System.Drawing.Size(49, 13)
        Me.lblCourse3.TabIndex = 6
        Me.lblCourse3.Text = "&Course 3"
        Me.lblCourse3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblCourse4
        '
        Me.lblCourse4.Location = New System.Drawing.Point(12, 136)
        Me.lblCourse4.Name = "lblCourse4"
        Me.lblCourse4.Size = New System.Drawing.Size(49, 13)
        Me.lblCourse4.TabIndex = 9
        Me.lblCourse4.Text = "&Course 4"
        Me.lblCourse4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblCourse5
        '
        Me.lblCourse5.Location = New System.Drawing.Point(12, 180)
        Me.lblCourse5.Name = "lblCourse5"
        Me.lblCourse5.Size = New System.Drawing.Size(49, 13)
        Me.lblCourse5.TabIndex = 12
        Me.lblCourse5.Text = "&Course 5"
        Me.lblCourse5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblCourse6
        '
        Me.lblCourse6.Location = New System.Drawing.Point(12, 228)
        Me.lblCourse6.Name = "lblCourse6"
        Me.lblCourse6.Size = New System.Drawing.Size(49, 13)
        Me.lblCourse6.TabIndex = 15
        Me.lblCourse6.Text = "&Course 6"
        Me.lblCourse6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtCourse2
        '
        Me.txtCourse2.Location = New System.Drawing.Point(76, 52)
        Me.txtCourse2.Name = "txtCourse2"
        Me.txtCourse2.Size = New System.Drawing.Size(100, 20)
        Me.txtCourse2.TabIndex = 4
        Me.txtCourse2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ttipSemesterAverage.SetToolTip(Me.txtCourse2, "The textbox that the user enters the Course 2 grade.")
        '
        'txtCourse5
        '
        Me.txtCourse5.Location = New System.Drawing.Point(76, 177)
        Me.txtCourse5.Name = "txtCourse5"
        Me.txtCourse5.Size = New System.Drawing.Size(100, 20)
        Me.txtCourse5.TabIndex = 13
        Me.txtCourse5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ttipSemesterAverage.SetToolTip(Me.txtCourse5, "The textbox that the user enters the Course 5 grade.")
        '
        'txtCourse4
        '
        Me.txtCourse4.Location = New System.Drawing.Point(76, 133)
        Me.txtCourse4.Name = "txtCourse4"
        Me.txtCourse4.Size = New System.Drawing.Size(100, 20)
        Me.txtCourse4.TabIndex = 10
        Me.txtCourse4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ttipSemesterAverage.SetToolTip(Me.txtCourse4, "The textbox that the user enters the Course 4 grade.")
        '
        'txtCourse3
        '
        Me.txtCourse3.Location = New System.Drawing.Point(76, 89)
        Me.txtCourse3.Name = "txtCourse3"
        Me.txtCourse3.Size = New System.Drawing.Size(100, 20)
        Me.txtCourse3.TabIndex = 7
        Me.txtCourse3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ttipSemesterAverage.SetToolTip(Me.txtCourse3, "The textbox that the user enters the Course 3 grade.")
        '
        'txtCourse6
        '
        Me.txtCourse6.Location = New System.Drawing.Point(76, 225)
        Me.txtCourse6.Name = "txtCourse6"
        Me.txtCourse6.Size = New System.Drawing.Size(100, 20)
        Me.txtCourse6.TabIndex = 16
        Me.txtCourse6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ttipSemesterAverage.SetToolTip(Me.txtCourse6, "The textbox that the user enters the Course 6 grade.")
        '
        'lblCourse1Grade
        '
        Me.lblCourse1Grade.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCourse1Grade.Location = New System.Drawing.Point(202, 12)
        Me.lblCourse1Grade.Name = "lblCourse1Grade"
        Me.lblCourse1Grade.Size = New System.Drawing.Size(130, 20)
        Me.lblCourse1Grade.TabIndex = 2
        Me.lblCourse1Grade.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ttipSemesterAverage.SetToolTip(Me.lblCourse1Grade, "The output label for the letter grade of the Course 1 textbox.")
        '
        'lblCourse2Grade
        '
        Me.lblCourse2Grade.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCourse2Grade.Location = New System.Drawing.Point(202, 52)
        Me.lblCourse2Grade.Name = "lblCourse2Grade"
        Me.lblCourse2Grade.Size = New System.Drawing.Size(130, 20)
        Me.lblCourse2Grade.TabIndex = 5
        Me.lblCourse2Grade.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ttipSemesterAverage.SetToolTip(Me.lblCourse2Grade, "The output label for the letter grade of the Course 2 textbox.")
        '
        'lblCourse3Grade
        '
        Me.lblCourse3Grade.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCourse3Grade.Location = New System.Drawing.Point(202, 89)
        Me.lblCourse3Grade.Name = "lblCourse3Grade"
        Me.lblCourse3Grade.Size = New System.Drawing.Size(130, 20)
        Me.lblCourse3Grade.TabIndex = 8
        Me.lblCourse3Grade.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ttipSemesterAverage.SetToolTip(Me.lblCourse3Grade, "The output label for the letter grade of the Course 3 textbox.")
        '
        'lblCourse4Grade
        '
        Me.lblCourse4Grade.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCourse4Grade.Location = New System.Drawing.Point(202, 135)
        Me.lblCourse4Grade.Name = "lblCourse4Grade"
        Me.lblCourse4Grade.Size = New System.Drawing.Size(130, 20)
        Me.lblCourse4Grade.TabIndex = 11
        Me.lblCourse4Grade.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ttipSemesterAverage.SetToolTip(Me.lblCourse4Grade, "The output label for the letter grade of the Course 4 textbox.")
        '
        'lblCourse5Grade
        '
        Me.lblCourse5Grade.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCourse5Grade.Location = New System.Drawing.Point(202, 177)
        Me.lblCourse5Grade.Name = "lblCourse5Grade"
        Me.lblCourse5Grade.Size = New System.Drawing.Size(130, 20)
        Me.lblCourse5Grade.TabIndex = 14
        Me.lblCourse5Grade.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ttipSemesterAverage.SetToolTip(Me.lblCourse5Grade, "The output label for the letter grade of the Course 5 textbox.")
        '
        'lblCourse6Grade
        '
        Me.lblCourse6Grade.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCourse6Grade.Location = New System.Drawing.Point(202, 225)
        Me.lblCourse6Grade.Name = "lblCourse6Grade"
        Me.lblCourse6Grade.Size = New System.Drawing.Size(130, 20)
        Me.lblCourse6Grade.TabIndex = 17
        Me.lblCourse6Grade.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ttipSemesterAverage.SetToolTip(Me.lblCourse6Grade, "The output label for the letter grade of the Course 6 textbox.")
        '
        'lblSemester
        '
        Me.lblSemester.Location = New System.Drawing.Point(12, 277)
        Me.lblSemester.Name = "lblSemester"
        Me.lblSemester.Size = New System.Drawing.Size(51, 13)
        Me.lblSemester.TabIndex = 18
        Me.lblSemester.Text = "&Semester"
        Me.lblSemester.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblSemesterPercent
        '
        Me.lblSemesterPercent.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSemesterPercent.Location = New System.Drawing.Point(76, 270)
        Me.lblSemesterPercent.Name = "lblSemesterPercent"
        Me.lblSemesterPercent.Size = New System.Drawing.Size(100, 20)
        Me.lblSemesterPercent.TabIndex = 19
        Me.lblSemesterPercent.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ttipSemesterAverage.SetToolTip(Me.lblSemesterPercent, "The semester label for what output the array dumps all of the Course values into," &
        " it is rounded to the nearest two decimals and is the average amongst the 6 inpu" &
        "tted grades.")
        '
        'lblSemesterGrade
        '
        Me.lblSemesterGrade.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSemesterGrade.Location = New System.Drawing.Point(202, 270)
        Me.lblSemesterGrade.Name = "lblSemesterGrade"
        Me.lblSemesterGrade.Size = New System.Drawing.Size(130, 20)
        Me.lblSemesterGrade.TabIndex = 20
        Me.lblSemesterGrade.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ttipSemesterAverage.SetToolTip(Me.lblSemesterGrade, "Displays the letter grade for the semester average.")
        '
        'lblOutput
        '
        Me.lblOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOutput.Location = New System.Drawing.Point(15, 307)
        Me.lblOutput.Name = "lblOutput"
        Me.lblOutput.Size = New System.Drawing.Size(317, 168)
        Me.lblOutput.TabIndex = 21
        Me.ttipSemesterAverage.SetToolTip(Me.lblOutput, "The output label, this takes care of informing the user on input validation, howe" &
        "ver if the user input is validated the grade that is accepted is displayed on a " &
        "new line in the textbox.")
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(15, 478)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(75, 23)
        Me.btnCalculate.TabIndex = 22
        Me.btnCalculate.Text = "&Calculate"
        Me.ttipSemesterAverage.SetToolTip(Me.btnCalculate, "The calculate button, takes care of the input validation by calling the function " &
        "and it displays the semester average.")
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnReset.Location = New System.Drawing.Point(132, 478)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(75, 23)
        Me.btnReset.TabIndex = 23
        Me.btnReset.Text = "&Reset"
        Me.ttipSemesterAverage.SetToolTip(Me.btnReset, "Resets the form entirely.")
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(257, 478)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 24
        Me.btnExit.Text = "&Exit"
        Me.ttipSemesterAverage.SetToolTip(Me.btnExit, "Exits the program.")
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'frmSemesterGrades
        '
        Me.AcceptButton = Me.btnCalculate
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnReset
        Me.ClientSize = New System.Drawing.Size(344, 510)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.lblOutput)
        Me.Controls.Add(Me.lblSemesterGrade)
        Me.Controls.Add(Me.lblSemesterPercent)
        Me.Controls.Add(Me.lblSemester)
        Me.Controls.Add(Me.lblCourse6Grade)
        Me.Controls.Add(Me.lblCourse5Grade)
        Me.Controls.Add(Me.lblCourse4Grade)
        Me.Controls.Add(Me.lblCourse3Grade)
        Me.Controls.Add(Me.lblCourse2Grade)
        Me.Controls.Add(Me.lblCourse1Grade)
        Me.Controls.Add(Me.txtCourse6)
        Me.Controls.Add(Me.txtCourse3)
        Me.Controls.Add(Me.txtCourse4)
        Me.Controls.Add(Me.txtCourse5)
        Me.Controls.Add(Me.txtCourse2)
        Me.Controls.Add(Me.lblCourse6)
        Me.Controls.Add(Me.lblCourse5)
        Me.Controls.Add(Me.lblCourse4)
        Me.Controls.Add(Me.lblCourse3)
        Me.Controls.Add(Me.lblCourse2)
        Me.Controls.Add(Me.txtCourse1)
        Me.Controls.Add(Me.lblCourse1)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmSemesterGrades"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Semester Grades"
        Me.ttipSemesterAverage.SetToolTip(Me, "The form of the program, this is used as the base for the form and all of it's co" &
        "ntrols.")
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblCourse1 As Label
    Friend WithEvents txtCourse1 As TextBox
    Friend WithEvents lblCourse2 As Label
    Friend WithEvents lblCourse3 As Label
    Friend WithEvents lblCourse4 As Label
    Friend WithEvents lblCourse5 As Label
    Friend WithEvents lblCourse6 As Label
    Friend WithEvents txtCourse2 As TextBox
    Friend WithEvents txtCourse5 As TextBox
    Friend WithEvents txtCourse4 As TextBox
    Friend WithEvents txtCourse3 As TextBox
    Friend WithEvents txtCourse6 As TextBox
    Friend WithEvents lblCourse1Grade As Label
    Friend WithEvents lblCourse2Grade As Label
    Friend WithEvents lblCourse3Grade As Label
    Friend WithEvents lblCourse4Grade As Label
    Friend WithEvents lblCourse5Grade As Label
    Friend WithEvents lblCourse6Grade As Label
    Friend WithEvents lblSemester As Label
    Friend WithEvents lblSemesterPercent As Label
    Friend WithEvents lblSemesterGrade As Label
    Friend WithEvents lblOutput As Label
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents ttipSemesterAverage As ToolTip
End Class
