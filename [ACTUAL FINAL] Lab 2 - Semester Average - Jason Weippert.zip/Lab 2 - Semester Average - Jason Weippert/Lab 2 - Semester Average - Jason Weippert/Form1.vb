﻿'Name: Jason Weippert
'Date: 02/04/2019
'File Name: Lab 2 - Semester Average - Jason Weippert
'Description: The user inputs 6 grades, they are cased into their appropriate percent to letter grade after being validated numerically, then stored into an array. Once all textboxes are validated, the program dumps the array after finding the average and displaying it, displaying the semester average by percent and grade letter.


Option Strict On

Public Class frmSemesterGrades
#Region "Declarations"
    Dim gradeSum As Integer 'Sum of all inputted grades
    Dim gradeAverage As Integer = 6 'number used to find average.
    Dim userInput As Integer 'user input
    Dim gradeLetter As String 'grade letter we use for case

#End Region


    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click

        Call Function() inputValidation() 'The button is pressed calling the input-validation for each grade.



        Dim courseGrades As String() = {txtCourse1.Text, txtCourse2.Text, txtCourse3.Text, txtCourse4.Text, txtCourse5.Text, txtCourse6.Text} 'textbox array for the values, we dim it here because at this point all of the textbox values are declared, and we can set them into an array.
        For Each value As Integer In courseGrades 'Loop for every value in the textbox array, taking all inputs and tallying them to the sum.
            gradeSum += value 'calculate sum
        Next
        lblSemesterPercent.Text = Math.Round(gradeSum / gradeAverage, 2).ToString 'calculate average number for all grades
        lblSemesterGrade.Text = gradeValidation(CDbl(lblSemesterPercent.Text)) 'display average number grade
        'disable entries with being tampered with once loop ends


    End Sub

    Public Function inputValidation() As Double
#Region "Validation"












#End Region
    End Function

    Public Function gradeValidation(ByVal notUserInput As Double) As String 'This function takes care of determining the letter grade associated with the percentage grade values.
        Dim letterGrade As String = ""
        Select Case notUserInput
            Case 0 To 49
                letterGrade = "F"
            Case 50 To 52
                letterGrade = "D-"
            Case 53 To 56
                letterGrade = "D"
            Case 57 To 59
                letterGrade = "D+"
            Case 60 To 62
                letterGrade = "C-"
            Case 63 To 66
                letterGrade = "C"
            Case 67 To 69
                letterGrade = "C+"
            Case 70 To 72
                letterGrade = "B-"
            Case 73 To 76
                letterGrade = "B"
            Case 77 To 79
                letterGrade = "B+"
            Case 80 To 84
                letterGrade = "A-"
            Case 85 To 89
                letterGrade = "A"
            Case 90 To 100
                letterGrade = "A+"

        End Select

        Return letterGrade
    End Function

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
#Region "Reset"
        btnCalculate.Enabled = True
        txtCourse1.Enabled = True
        txtCourse2.Enabled = True
        txtCourse3.Enabled = True
        txtCourse4.Enabled = True
        txtCourse5.Enabled = True
        txtCourse6.Enabled = True


        txtCourse1.Focus()

        txtCourse1.Clear()
        txtCourse2.Clear()
        txtCourse3.Clear()
        txtCourse4.Clear()
        txtCourse5.Clear()
        txtCourse6.Clear()


        lblCourse1Grade.Text = ""
        lblCourse2Grade.Text = ""
        lblCourse3Grade.Text = ""
        lblCourse4Grade.Text = ""
        lblCourse5Grade.Text = ""
        lblCourse6Grade.Text = ""

        lblSemesterPercent.Text = ""
        lblSemesterGrade.Text = ""
        lblOutput.Text = ""
        gradeSum = 0


#End Region
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub frmSemesterGrades_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub



    'Below are all of these text value leave_events, this activates once the user tabs out of a textbox. This is to ensure validation per textbox.
    Private Sub txtCourse1_Leave(sender As Object, e As EventArgs) Handles txtCourse1.Leave
#Region "Course 1"
        If IsNumeric(txtCourse1.Text) = True Then 'Does numerical input checking for the textbox value
            Integer.TryParse(txtCourse1.Text, userInput) 'Tryparses Integer Value
            If userInput < 0 Or userInput > 100 Then 'If Input Range is Invalid
                txtCourse1.Focus()
                lblOutput.Text = "Please enter a value for the suitable range for Grade 1 (0-100)." 'The range of the acceptable values
            Else
                lblOutput.Text += userInput.ToString & vbCrLf 'New line in textbox to format the textbox inputs
                lblCourse1Grade.Text = gradeValidation(CDbl(txtCourse1.Text))
                txtCourse1.Enabled = False


            End If
        End If


        If txtCourse1.Text = "" Then
            lblOutput.Text = "Please enter a whole number for Grade 1."
            txtCourse1.Focus()
        End If
#End Region

    End Sub

    Private Sub txtCourse2_Leave(sender As Object, e As EventArgs) Handles txtCourse2.Leave

#Region "Grade 2"
        If IsNumeric(txtCourse2.Text) = True Then 'Does numerical input checking
            Integer.TryParse(txtCourse2.Text, userInput) 'Tryparses Integer Value
            If userInput < 0 Or userInput > 100 Then 'If Input Range is Invalid
                lblOutput.Text = "Please enter a value for the suitable range for Grade 2 (0-100).\n" 'The range of the acceptable values
            Else
                lblOutput.Text += userInput.ToString & vbCrLf 'New line in textbox to format the textbox inputs
                lblCourse2Grade.Text = gradeValidation(CDbl(txtCourse2.Text))
                txtCourse2.Enabled = False


            End If
        End If

        If txtCourse2.Text = "" Then
            lblOutput.Text = "Please enter a whole number for Grade 2."
            txtCourse2.Focus()
        End If
#End Region

    End Sub

    Private Sub txtCourse3_Leave(sender As Object, e As EventArgs) Handles txtCourse3.Leave
#Region "Course 3"
        If IsNumeric(txtCourse3.Text) = True Then 'Does numerical input checking
            Integer.TryParse(txtCourse3.Text, userInput) 'Tryparses Integer Value
            If userInput < 0 Or userInput > 100 Then 'If Input Range is Invalid
                lblOutput.Text = "Please enter a value for the suitable range for Grade 3 (0-100).\n" 'The range of the acceptable values

            Else
                lblOutput.Text += userInput.ToString & vbCrLf 'New line in textbox to format the textbox inputs
                lblCourse3Grade.Text = gradeValidation(CDbl(txtCourse3.Text))
                txtCourse3.Enabled = False

            End If
        End If

        If txtCourse3.Text = "" Then
            lblOutput.Text = "Please enter a whole number for Grade 3."
            txtCourse3.Focus()
        End If
#End Region
    End Sub

    Private Sub txtCourse4_Leave(sender As Object, e As EventArgs) Handles txtCourse4.Leave
#Region "Grade 4"
        If IsNumeric(txtCourse4.Text) = True Then 'Does numerical input checking
            Integer.TryParse(txtCourse4.Text, userInput) 'Tryparses Integer Value
            If userInput < 0 Or userInput > 100 Then 'If Input Range is Invalid
                lblOutput.Text = "Please enter a value for the suitable range for Grade 4 (0-100).\n" 'The range of the acceptable values
            Else
                lblOutput.Text += userInput.ToString & vbCrLf 'New line in textbox to format the textbox inputs
                lblCourse4Grade.Text = gradeValidation(CDbl(txtCourse4.Text))
                txtCourse4.Enabled = False

            End If
        End If


        If txtCourse4.Text = "" Then
            lblOutput.Text = "Please enter a whole number for Grade 4."
            txtCourse4.Focus()
        End If
#End Region
    End Sub

    Private Sub txtCourse5_Leave(sender As Object, e As EventArgs) Handles txtCourse5.Leave
#Region "Grade 5"
        If IsNumeric(txtCourse5.Text) = True Then 'Does numerical input checking
            Integer.TryParse(txtCourse5.Text, userInput) 'Tryparses Integer Value
            If userInput < 0 Or userInput > 100 Then 'If Input Range is Invalid
                lblOutput.Text = "Please enter a value for the suitable range for Grade 5 (0-100).\n" 'The range of the acceptable values
            Else
                lblOutput.Text += userInput.ToString & vbCrLf 'New line in textbox to format the textbox inputs
                lblCourse5Grade.Text = gradeValidation(CDbl(txtCourse5.Text))
                txtCourse5.Enabled = False

            End If
        End If

        If txtCourse5.Text = "" Then
            lblOutput.Text = "Please enter a whole number for Grade 5."
            txtCourse5.Focus()
        End If
#End Region
    End Sub

    Private Sub txtCourse6_Leave(sender As Object, e As EventArgs) Handles txtCourse6.Leave
#Region "Grade 6"
        If IsNumeric(txtCourse6.Text) = True Then 'Does numerical input checking
            Integer.TryParse(txtCourse6.Text, userInput) 'Tryparses Integer Value
            If userInput < 0 Or userInput > 100 Then 'If Input Range is Invalid
                lblOutput.Text = "Please enter a value for the suitable range for Grade 6 (0-100)." 'The range of the acceptable values
            Else
                lblOutput.Text += userInput.ToString & vbCrLf 'New line in textbox to format the textbox inputs
                lblCourse6Grade.Text = gradeValidation(CDbl(txtCourse6.Text))
                txtCourse6.Enabled = False

            End If
        End If

        If txtCourse6.Text = "" Then
            lblOutput.Text = "Please enter a whole number for Grade 6."
            txtCourse6.Focus()
        End If
#End Region
    End Sub
End Class
